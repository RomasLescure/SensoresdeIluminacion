package com.example.question;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ResultsActivity extends AppCompatActivity {
    private List<Question> questionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        questionList = (List<Question>) getIntent().getSerializableExtra("questionList");
        int score = getIntent().getIntExtra("score", 0);

        TextView scoreTextView = findViewById(R.id.scoreTextView);
        scoreTextView.setText("Puntaje: " + score+"/5");

        TextView resultsTextView = findViewById(R.id.resultsTextView);
        resultsTextView.setText(generateResultsText());
    }

    private String generateResultsText() {
        StringBuilder resultsText = new StringBuilder();
        for (int i = 0; i < questionList.size(); i++) {
            Question question = questionList.get(i);
            String status = question.isCorrect() ? "Correcta" : "Incorrecta";
            resultsText.append("Pregunta ").append(i + 1).append(": ").append(status).append("\n");
        }
        return resultsText.toString();
    }
}
